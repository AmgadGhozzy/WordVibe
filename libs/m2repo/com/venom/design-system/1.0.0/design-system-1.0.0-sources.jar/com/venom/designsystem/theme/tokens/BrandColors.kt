package com.venom.designsystem.theme.tokens

import com.venom.designsystem.theme.Emerald500
import com.venom.designsystem.theme.Emerald600
import com.venom.designsystem.theme.Indigo600
import com.venom.designsystem.theme.Orange400
import com.venom.designsystem.theme.Orange600
import com.venom.designsystem.theme.Red500
import com.venom.designsystem.theme.Red600
import com.venom.designsystem.theme.Slate100
import com.venom.designsystem.theme.Slate200
import com.venom.designsystem.theme.Slate300
import com.venom.designsystem.theme.Slate50
import com.venom.designsystem.theme.Slate600
import com.venom.designsystem.theme.Slate700
import com.venom.designsystem.theme.Slate800
import com.venom.designsystem.theme.Slate900
import com.venom.designsystem.theme.Slate950
import com.venom.designsystem.theme.Violet600
import com.venom.designsystem.theme.White

object BrandColors {

    // Brand
    val PrimaryLight = Indigo600
    val OnPrimaryLight = White

    val PrimaryDark = Indigo600
    val OnPrimaryDark = White

    val SecondaryLight = Violet600
    val OnSecondaryLight = White

    val SecondaryDark = Violet600
    val OnSecondaryDark = White

    val TertiaryLight = Orange600
    val OnTertiaryLight = Slate950

    val TertiaryDark = Orange400
    val OnTertiaryDark = Slate950

    // Status
    val SuccessLight = Emerald600
    val OnSuccessLight = White

    val SuccessDark = Emerald500
    val OnSuccessDark = White

    val ErrorLight = Red600
    val OnErrorLight = White

    val ErrorDark = Red500
    val OnErrorDark = White

    // Light surfaces
    val NeutralLightBg = Slate100
    val NeutralLightSurface = White
    val NeutralLightSurfaceLow = Slate100

    // Dark surfaces
    val NeutralDarkBg = Slate950
    val NeutralDarkSurface = Slate900
    val NeutralDarkSurfaceLow = Slate800

    // Text
    val OnLight = Slate900
    val OnLightMuted = Slate600

    val OnDark = Slate50
    val OnDarkMuted = Slate300

    // Borders
    val OutlineLight = Slate300
    val OutlineVariantLight = Slate200

    val OutlineDark = Slate700
    val OutlineVariantDark = Slate800
}
