package com.venom.designsystem.theme.tokens

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RadialGradientShader
import androidx.compose.ui.graphics.ShaderBrush
import com.venom.designsystem.theme.Amber400
import com.venom.designsystem.theme.Amber500
import com.venom.designsystem.theme.Emerald500
import com.venom.designsystem.theme.Emerald600
import com.venom.designsystem.theme.Indigo50
import com.venom.designsystem.theme.Indigo500
import com.venom.designsystem.theme.Indigo600
import com.venom.designsystem.theme.Indigo700
import com.venom.designsystem.theme.Indigo950
import com.venom.designsystem.theme.Orange100
import com.venom.designsystem.theme.Orange200
import com.venom.designsystem.theme.Orange400
import com.venom.designsystem.theme.Orange600
import com.venom.designsystem.theme.Slate200
import com.venom.designsystem.theme.Slate50
import com.venom.designsystem.theme.StreakBackgroundDeep
import com.venom.designsystem.theme.StreakSurfaceDark
import com.venom.designsystem.theme.Transparent
import com.venom.designsystem.theme.Violet400
import com.venom.designsystem.theme.Violet500
import com.venom.designsystem.theme.White

@Immutable
data class SynapseGradients(
    val primary: Brush,
    val accent: Brush,
    val premium: Brush,
    val page: ShaderBrush,
    val streakHero: Brush,
    val shimmer: Brush,
    val success: Brush,
)

private object LightGradients {

    val primary = Brush.linearGradient(
        colors = listOf(
            Indigo600,
            Indigo500
        )
    )

    val accent = Brush.linearGradient(
        colors = listOf(
            Indigo600,
            Indigo500,
            Violet400,
        )
    )

    val premium = Brush.linearGradient(
        colors = listOf(Amber400, Orange400)
    )

    val streakHero = Brush.linearGradient(
        colors = listOf(
            White,
            Orange100,
            Orange200
        )
    )

    val success = Brush.linearGradient(
        colors = listOf(
            Emerald500,
            Emerald600
        )
    )

    val shimmer = Brush.linearGradient(
        colors = listOf(
            Transparent,
            Slate200.copy(alpha = 0.5f),
            Transparent
        ),
        start = Offset.Zero,
        end = Offset(800f, 0f)
    )

    val page = object : ShaderBrush() {
        override fun createShader(size: Size) =
            RadialGradientShader(
                center = Offset(size.width * 0.5f, 0f),
                radius = size.width * 0.85f,
                colors = listOf(
                    Indigo50.copy(alpha = 0.5f),
                    Slate50
                ),
                colorStops = listOf(0f, 0.7f),
            )
    }
}

private object DarkGradients {

    val primary = Brush.linearGradient(
        colors = listOf(
            Indigo600,
            Indigo500
        )
    )

    val accent = Brush.linearGradient(
        colors = listOf(
            Indigo700,
            Indigo600,
            Violet500
        )
    )

    val premium = Brush.linearGradient(
        colors = listOf(Amber500, Orange600)
    )
    val streakHero = Brush.linearGradient(
        colors = listOf(StreakBackgroundDeep, StreakSurfaceDark, StreakBackgroundDeep)
    )

    val success = Brush.linearGradient(
        colors = listOf(
            Emerald600,
            Emerald500
        )
    )

    val shimmer = Brush.linearGradient(
        colors = listOf(
            Transparent,
            Color.White.copy(alpha = 0.13f),
            Transparent
        ),
        start = Offset.Zero,
        end = Offset(800f, 0f)
    )

    val page = object : ShaderBrush() {
        override fun createShader(size: Size) =
            RadialGradientShader(
                center = Offset(size.width * 0.5f, 0f),
                radius = size.width * 0.85f,
                colors = listOf(
                    Indigo950.copy(alpha = 0.3f),
                    BrandColors.NeutralDarkBg
                ),
                colorStops = listOf(0f, 0.7f),
            )
    }
}

val LightSynapseGradients = SynapseGradients(
    primary = LightGradients.primary,
    accent = LightGradients.accent,
    premium = LightGradients.premium,
    streakHero = LightGradients.streakHero,
    page = LightGradients.page,
    shimmer = LightGradients.shimmer,
    success = LightGradients.success
)

val DarkSynapseGradients = SynapseGradients(
    primary = DarkGradients.primary,
    accent = DarkGradients.accent,
    premium = DarkGradients.premium,
    streakHero = DarkGradients.streakHero,
    page = DarkGradients.page,
    shimmer = DarkGradients.shimmer,
    success = DarkGradients.success,
)

val defaultGradientTokens = DarkSynapseGradients