package com.venom.designsystem.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import com.venom.designsystem.theme.tokens.RadiusTokens
import com.venom.designsystem.theme.tokens.ShadowTokens
import com.venom.designsystem.theme.tokens.SpacingTokens
import com.venom.designsystem.theme.tokens.SynapseGradients
import com.venom.designsystem.theme.tokens.defaultGradientTokens
import com.venom.designsystem.theme.tokens.defaultRadiusTokens
import com.venom.designsystem.theme.tokens.defaultShadowTokens
import com.venom.designsystem.theme.tokens.defaultSpacingTokens

data class SynapseTokens(
    val semantic: SemanticColors,
    val gradients: SynapseGradients,
    val spacing: SpacingTokens,
    val radius: RadiusTokens,
    val shadows: ShadowTokens,
)

val MaterialTheme.synapse: SynapseTokens
    @Composable
    @ReadOnlyComposable
    get() = SynapseTokens(
        semantic = LocalSemanticColors.current,
        gradients = LocalGradientTokens.current,
        spacing = LocalSpacingTokens.current,
        radius = LocalRadiusTokens.current,
        shadows = LocalShadowTokens.current,
    )

val LocalGradientTokens = staticCompositionLocalOf {
    defaultGradientTokens
}

val LocalSemanticColors = staticCompositionLocalOf {
    defaultSemanticColors
}

val LocalSpacingTokens = staticCompositionLocalOf {
    defaultSpacingTokens
}

val LocalRadiusTokens = staticCompositionLocalOf {
    defaultRadiusTokens
}

val LocalShadowTokens = staticCompositionLocalOf {
    defaultShadowTokens
}
